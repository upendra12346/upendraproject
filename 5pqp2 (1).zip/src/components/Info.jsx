import React from "react";

function Info() {
  return (
    <div class="note">
    <h1 class="note">javascript and react.js</h1>
    <p class="note">A basic web dev React Js bootcamp </p>
    </div>
     );
}

export default Info;